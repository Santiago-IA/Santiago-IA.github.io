
=========================
📘 MANUAL DE USUARIO
=========================

Bienvenido al Sistema de Gestión Agrícola. Esta guía lo orientará en el uso básico del sistema.

🔐 INGRESO AL SISTEMA
- Al abrir la aplicación, accederá directamente al panel principal.

🌱 GESTIÓN DE CULTIVOS
- Puede registrar nuevos cultivos con fecha, insumos, cantidad y ubicación.
- Puede editar o eliminar registros directamente desde la tabla.
- Las estadísticas se actualizarán automáticamente.

🚜 GESTIÓN DE MAQUINARIA
- Registre maquinaria con referencia, estado y fecha de compra.
- Edite o elimine maquinaria según sea necesario.

👷 GESTIÓN DE COLABORADORES
- Agregue colaboradores indicando nombre, cargo y contacto.
- Edite o elimine fácilmente.

📁 GESTIÓN DOCUMENTAL
- Suba contratos, nóminas u otros documentos importantes.
- Visualice y descargue los archivos desde la tabla.
- Elimine documentos no deseados.

🔔 NOTIFICACIONES
- Reciba alertas locales cuando se actualice un cultivo (riego, fertilización, etc.).

📦 EXPORTACIÓN
- Puede exportar los datos a Excel con un clic.

📴 FUNCIONALIDAD OFFLINE
- Puede trabajar sin conexión a internet.



=========================
🛠 MANUAL DE DESPLIEGUE
=========================

Requisitos:
- Node.js 16+
- Navegador moderno (Chrome, Firefox, Edge)
- npm

Pasos de despliegue:
1. Clonar el repositorio:
   git clone https://github.com/tu-usuario/sistema-agricola.git

2. Instalar dependencias:
   cd sistema-agricola
   npm install

3. Ejecutar servidor de desarrollo:
   npm run dev

4. Para producción:
   npm run build
   Luego desplegar la carpeta /dist en un servidor estático (Netlify, Vercel, etc).

Nota:
- La base de datos se guarda en IndexedDB.
- No necesita base de datos externa ni backend para funcionar.


=========================
👨‍💻 MANUAL DE DESARROLLADOR
=========================

Estructura del proyecto:
src/
├── components/
│   ├── Dashboard.vue
│   ├── DocumentUploader.vue
│   ├── NotificationBell.vue
│   └── charts/
│       ├── BarChart.vue
│       └── LineChart.vue
├── database/
│   └── db.js
└── main.js

Tecnologías usadas:
- Vue 3 (Composition API)
- Dexie.js (IndexedDB)
- Tailwind CSS
- Chart.js
- FileSaver + xlsx
- Vite

IndexedDB:
- db.js contiene las tablas: crops, machinery, collaborators, documents, notifications.

Notificaciones:
- Se generan al actualizar cultivos (ej: riego iniciado).
- Se almacenan localmente (notifications table).
- Se visualizan en NotificationBell.vue.

Gestión documental:
- DocumentUploader.vue permite subir archivos como blobs.
- Se almacenan en IndexedDB como Blob y pueden descargarse.

Tips:
- Para desarrollo offline, use navegador con soporte completo a IndexedDB.
- Use la consola para verificar el contenido de la base de datos (Dexie.debug = true).
