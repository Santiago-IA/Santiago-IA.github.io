<template>
  <div class="p-6">
    <h2 class="text-2xl font-bold text-green-700 mb-4">📁 Gestión Documental</h2>
    <DocumentUploader />
  </div>
</template>

<script>
import DocumentUploader from '@/components/DocumentUploader.vue';

export default {
  components: { DocumentUploader }
};
</script>
