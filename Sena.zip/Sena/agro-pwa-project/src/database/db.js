import Dexie from 'dexie';

export const db = new Dexie('AgroDB');
db.version(2).stores({
  documents: '++id, type, fileName, uploadedAt',
  crops: '++id, date, inputs, quantity, location',
  machinery: '++id, reference, status, purchaseDate',
  collaborators: '++id, name, role, contact',
  notifications: '++id, type, message, date, read'
});
