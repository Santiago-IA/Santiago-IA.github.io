<template>
  <div class="min-h-screen bg-gray-100">
    <nav class="bg-green-700 text-white p-4 flex justify-between items-center">
      <h1 class="font-bold text-lg">🌾 AGRO APP</h1>
      <ul class="flex space-x-4">
        <li><button @click="view = 'crop'" class="hover:underline">Cultivo</button></li>
        <li><button @click="view = 'machinery'" class="hover:underline">Maquinaria</button></li>
        <li><button @click="view = 'collaborator'" class="hover:underline">Colaborador</button></li>
        <li><button @click="view = 'dashboard'" class="hover:underline">Dashboard</button></li>
      </ul>
    </nav>

    <main class="p-4">
      <RegisterCrop v-if="view === 'crop'" />
      <RegisterMachinery v-if="view === 'machinery'" />
      <RegisterCollaborator v-if="view === 'collaborator'" />
      <Dashboard v-if="view === 'dashboard'" />
    </main>
  </div>
</template>

<script>
import RegisterCrop from './components/RegisterCrop.vue';
import RegisterMachinery from './components/RegisterMachinery.vue';
import RegisterCollaborator from './components/RegisterCollaborator.vue';
import Dashboard from './components/Dashboard.vue';

export default {
  components: {
    RegisterCrop,
    RegisterMachinery,
    RegisterCollaborator,
    Dashboard
  },
  data() {
    return {
      view: 'dashboard' // Vista inicial
    };
  }
};
</script>
