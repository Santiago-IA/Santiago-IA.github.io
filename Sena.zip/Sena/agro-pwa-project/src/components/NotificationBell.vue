<template>
  <div class="relative">
    <button @click="toggleDropdown" class="relative">
      🔔
      <span v-if="unreadCount" class="absolute top-0 right-0 bg-red-600 text-white text-xs px-1 rounded-full">{{ unreadCount }}</span>
    </button>
    <div v-if="showDropdown" class="absolute bg-white border rounded shadow mt-2 w-64 z-50">
      <ul>
        <li v-for="notif in notifications" :key="notif.id" class="p-2 border-b text-sm">
          <strong>{{ notif.type.toUpperCase() }}:</strong> {{ notif.message }}
          <br>
          <small class="text-gray-500">{{ formatDate(notif.date) }}</small>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { db } from '../database/db';

export default {
  data() {
    return {
      notifications: [],
      showDropdown: false
    };
  },
  computed: {
    unreadCount() {
      return this.notifications.filter(n => !n.read).length;
    }
  },
  async mounted() {
    this.notifications = await db.notifications.orderBy('date').reverse().limit(10).toArray();
  },
  methods: {
    toggleDropdown() {
      this.showDropdown = !this.showDropdown;
    },
    formatDate(dateStr) {
      const d = new Date(dateStr);
      return d.toLocaleString();
    }
  }
};
</script>
