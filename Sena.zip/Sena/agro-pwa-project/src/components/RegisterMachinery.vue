<template>
  <div class="p-4 max-w-md mx-auto bg-white shadow-md rounded">
    <h2 class="text-xl font-bold mb-4">Registrar Maquinaria</h2>
    <form @submit.prevent="saveMachinery">
      <div class="mb-3">
        <label class="block">Referencia:</label>
        <input v-model="reference" type="text" class="w-full border rounded px-2 py-1" required />
      </div>

      <div class="mb-3">
        <label class="block">Estado:</label>
        <select v-model="status" class="w-full border rounded px-2 py-1" required>
          <option value="" disabled>Selecciona una opción</option>
          <option>Operativa</option>
          <option>En mantenimiento</option>
          <option>No operativa</option>
        </select>
      </div>

      <div class="mb-3">
        <label class="block">Fecha de compra:</label>
        <input v-model="purchaseDate" type="date" class="w-full border rounded px-2 py-1" required />
      </div>

      <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        Guardar
      </button>
    </form>
  </div>
</template>

<script>
import { db } from '../database/db';

export default {
  name: 'RegisterMachinery',
  data() {
    return {
      reference: '',
      status: '',
      purchaseDate: ''
    };
  },
  methods: {
    async saveMachinery() {
      await db.machinery.add({
        reference: this.reference,
        status: this.status,
        purchaseDate: this.purchaseDate
      });
      alert('Maquinaria registrada exitosamente');
      this.reference = '';
      this.status = '';
      this.purchaseDate = '';
    }
  }
};
</script>
