<template>
  <div class="p-4 max-w-md mx-auto bg-white shadow-md rounded">
    <h2 class="text-xl font-bold mb-4">Registrar Colaborador</h2>
    <form @submit.prevent="saveCollaborator">
      <div class="mb-3">
        <label class="block">Nombre:</label>
        <input v-model="name" type="text" class="w-full border rounded px-2 py-1" required />
      </div>

      <div class="mb-3">
        <label class="block">Cargo:</label>
        <input v-model="role" type="text" class="w-full border rounded px-2 py-1" required />
      </div>

      <div class="mb-3">
        <label class="block">Número de contacto:</label>
        <input v-model="contact" type="tel" class="w-full border rounded px-2 py-1" required />
      </div>

      <button type="submit" class="bg-emerald-600 text-white px-4 py-2 rounded hover:bg-emerald-700">
        Guardar
      </button>
    </form>
  </div>
</template>

<script>
import { db } from '../database/db';

export default {
  name: 'RegisterCollaborator',
  data() {
    return {
      name: '',
      role: '',
      contact: ''
    };
  },
  methods: {
    async saveCollaborator() {
      await db.collaborators.add({
        name: this.name,
        role: this.role,
        contact: this.contact
      });
      alert('Colaborador registrado exitosamente');
      this.name = '';
      this.role = '';
      this.contact = '';
    }
  }
};
</script>
