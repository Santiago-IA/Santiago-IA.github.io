<template>
  <div class="bg-white rounded shadow-md p-6">
    <h2 class="text-2xl font-bold text-green-700 mb-4">📁 Gestión Documental</h2>

    <!-- Subida -->
    <div class="mb-4 grid md:grid-cols-3 gap-4">
      <select v-model="docType" class="border px-3 py-2 rounded">
        <option value="" disabled selected>📄 Tipo de documento</option>
        <option>Contrato</option>
        <option>Nómina</option>
        <option>Otro</option>
      </select>

      <input type="file" @change="handleFile" class="border px-3 py-2 rounded" />

      <button
        @click="uploadFile"
        class="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded"
      >
        ➕ Subir
      </button>
    </div>

    <!-- Lista -->
    <div v-if="documents.length">
      <h3 class="text-xl font-semibold mb-3">📚 Documentos almacenados</h3>
      <table class="w-full border text-sm">
        <thead class="bg-gray-100">
          <tr>
            <th class="border p-2">Tipo</th>
            <th class="border p-2">Nombre</th>
            <th class="border p-2">Fecha de subida</th>
            <th class="border p-2">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="doc in documents" :key="doc.id">
            <td class="border p-2">{{ doc.type }}</td>
            <td class="border p-2">{{ doc.fileName }}</td>
            <td class="border p-2">{{ formatDate(doc.uploadedAt) }}</td>
            <td class="border p-2 text-center">
              <a
                :href="URL.createObjectURL(doc.file)"
                :download="doc.fileName"
                target="_blank"
                class="text-blue-600 hover:underline"
              >📎 Ver</a>
              <button
                @click="deleteDocument(doc.id)"
                class="text-red-600 ml-3 hover:underline"
              >🗑 Eliminar</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <p v-else class="text-gray-500">No hay documentos registrados.</p>
  </div>
</template>

<script>
import { db } from '../database/db';

export default {
  data() {
    return {
      documents: [],
      selectedFile: null,
      docType: ''
    };
    
  },
  async mounted() {
    this.loadDocuments();
  },
  methods: {
    handleFile(event) {
      this.selectedFile = event.target.files[0];
    },
    async uploadFile() {
      if (!this.selectedFile || !this.docType) {
        alert('Por favor selecciona un archivo y un tipo.');
        return;
      }

      const reader = new FileReader();
      reader.onload = async (e) => {
        const arrayBuffer = e.target.result;

        await db.documents.add({
          type: this.docType,
          file: new Blob([arrayBuffer], { type: this.selectedFile.type }),
          uploadedAt: new Date().toISOString(),
          fileName: this.selectedFile.name
        });

        this.docType = '';
        this.selectedFile = null;
        this.loadDocuments();
      };
      reader.readAsArrayBuffer(this.selectedFile);
    },
    async loadDocuments() {
      this.documents = await db.documents.toArray();
    },
    async deleteDocument(id) {
      if (confirm('¿Deseas eliminar este documento?')) {
        await db.documents.delete(id);
        this.loadDocuments();
      }
    },
    formatDate(dateString) {
      const date = new Date(dateString);
      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    }
  }
};
</script>
