<template>
  <div class="p-4 max-w-md mx-auto bg-white shadow-md rounded">
    <h2 class="text-xl font-bold mb-4">Registrar Cultivo</h2>
    <form @submit.prevent="saveCrop">
      <div class="mb-2">
        <label class="block">Fecha:</label>
        <input v-model="date" type="date" class="w-full border rounded px-2 py-1" required />
      </div>

      <div class="mb-2">
        <label class="block">Insumos usados:</label>
        <input v-model="inputs" type="text" class="w-full border rounded px-2 py-1" required />
      </div>

      <div class="mb-2">
        <label class="block">Cantidad:</label>
        <input v-model="quantity" type="number" class="w-full border rounded px-2 py-1" required />
      </div>

      <div class="mb-2">
        <label class="block">Ubicación:</label>
        <input v-model="location" type="text" class="w-full border rounded px-2 py-1" required />
      </div>

      <div class="mb-4">
        <label class="block">Foto del cultivo:</label>
        <input type="file" @change="handleFile" class="w-full" />
      </div>

      <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
        Guardar
      </button>
    </form>
  </div>
</template>

<script>
import { db } from '../database/db';

export default {
  name: 'RegisterCrop',
  data() {
    return {
      date: '',
      inputs: '',
      quantity: '',
      location: '',
      photo: null
    };
  },
  methods: {
    async handleFile(event) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          this.photo = e.target.result; // base64
        };
        reader.readAsDataURL(file);
      }
    },
    async saveCrop() {
      await db.crops.add({
        date: this.date || 'Sin fecha',
        inputs: this.inputs || 'Sin insumo',
        quantity: this.quantity || 0,
        location: this.location || 'Sin ubicación',
        photo: this.photo || ''
        });
      alert('Cultivo guardado exitosamente');
      this.date = '';
      this.inputs = '';
      this.quantity = '';
      this.location = '';
      this.photo = null;
    }
  }
};
</script>

<style scoped>
input, button {
  transition: all 0.2s ease;
}
</style>
