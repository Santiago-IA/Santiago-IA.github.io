<template>
  <div class="flex justify-end mb-4">
      <NotificationBell />
    <button
      @click="exportToExcel"
      class="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded shadow"
    >
      📥 Exportar a Excel
    </button>
  </div>

  <div class="p-6 max-w-6xl mx-auto bg-white rounded shadow-md">
    <h2 class="text-3xl font-bold mb-6 text-green-700">📊 Panel de Estadísticas</h2>

    <!-- Alertas de confirmación -->
    <div v-if="confirmationMessage" class="mb-4 p-3 bg-green-100 text-green-800 rounded">
      {{ confirmationMessage }}
    </div>

    <!-- Gráfico de cultivos por ubicación -->
    <div class="mb-8">
      <h3 class="text-xl font-semibold mb-2">🌱 Cantidad de cultivos por ubicación</h3>
      <BarChart v-if="locationData" :chart-data="locationData" />
      <p v-else class="text-gray-500">No hay datos suficientes para graficar.</p>
    </div>

    <!-- Gráfico de insumos por fecha -->
    <div class="mb-8">
      <h3 class="text-xl font-semibold mb-2">🧪 Insumos usados por fecha</h3>
      <LineChart v-if="inputsData" :chart-data="inputsData" />
      <p v-else class="text-gray-500">No hay datos suficientes para graficar.</p>
    </div>

    <!-- Tabla de cultivos editable -->
    <div class="mb-10">
      <h3 class="text-xl font-semibold mb-3">📄 Detalles de cultivos registrados</h3>
      <table class="w-full border text-sm">
        <thead class="bg-gray-100">
          <tr>
            <th class="border p-2">Fecha</th>
            <th class="border p-2">Insumos</th>
            <th class="border p-2">Cantidad</th>
            <th class="border p-2">Ubicación</th>
            <th class="border p-2">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="crop in crops" :key="crop.id">
            <td class="border p-2">
              <input v-if="editingId === crop.id" v-model="editForm.date" type="date" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ crop.date }}</span>
            </td>
            <td class="border p-2">
              <input v-if="editingId === crop.id" v-model="editForm.inputs" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ crop.inputs }}</span>
            </td>
            <td class="border p-2">
              <input v-if="editingId === crop.id" v-model="editForm.quantity" type="number" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ crop.quantity }}</span>
            </td>
            <td class="border p-2">
              <input v-if="editingId === crop.id" v-model="editForm.location" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ crop.location }}</span>
            </td>
            <td class="border p-2 text-center">
              <div v-if="editingId === crop.id" class="flex gap-2 justify-center">
                <button @click="updateCrop(crop.id)" class="bg-blue-500 text-white px-2 py-1 rounded">💾 Guardar</button>
                <button @click="cancelEdit" class="bg-gray-400 text-white px-2 py-1 rounded">❌ Cancelar</button>
              </div>
              <div v-else class="flex gap-2 justify-center">
                <button @click="startEdit(crop, 'crop')" class="bg-yellow-400 text-black px-2 py-1 rounded">✏️ Editar</button>
                <button @click="deleteCrop(crop.id)" class="bg-red-600 text-white px-2 py-1 rounded">🗑 Eliminar</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Tabla de maquinaria editable -->
    <div class="mb-10">
      <h3 class="text-xl font-semibold mb-3">🚜 Detalles de maquinaria</h3>
      <table class="w-full border text-sm">
        <thead class="bg-gray-100">
          <tr>
            <th class="border p-2">Referencia</th>
            <th class="border p-2">Estado</th>
            <th class="border p-2">Fecha de compra</th>
            <th class="border p-2">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in machinery" :key="item.id">
            <td class="border p-2">
              <input v-if="editingId === item.id" v-model="editForm.reference" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ item.reference }}</span>
            </td>
            <td class="border p-2">
              <input v-if="editingId === item.id" v-model="editForm.status" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ item.status }}</span>
            </td>
            <td class="border p-2">
              <input v-if="editingId === item.id" v-model="editForm.purchaseDate" type="date" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ item.purchaseDate }}</span>
            </td>
            <td class="border p-2 text-center">
              <div v-if="editingId === item.id" class="flex gap-2 justify-center">
                <button @click="updateMachinery(item.id)" class="bg-blue-500 text-white px-2 py-1 rounded">💾 Guardar</button>
                <button @click="cancelEdit" class="bg-gray-400 text-white px-2 py-1 rounded">❌ Cancelar</button>
              </div>
              <div v-else class="flex gap-2 justify-center">
                <button @click="startEdit(item, 'machinery')" class="bg-yellow-400 text-black px-2 py-1 rounded">✏️ Editar</button>
                <button @click="deleteMachinery(item.id)" class="bg-red-600 text-white px-2 py-1 rounded">🗑 Eliminar</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Tabla de colaboradores editable -->
    <div class="mb-10">
      <h3 class="text-xl font-semibold mb-3">👷 Detalles de colaboradores</h3>
      <table class="w-full border text-sm">
        <thead class="bg-gray-100">
          <tr>
            <th class="border p-2">Nombre</th>
            <th class="border p-2">Cargo</th>
            <th class="border p-2">Contacto</th>
            <th class="border p-2">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="col in collaborators" :key="col.id">
            <td class="border p-2">
              <input v-if="editingId === col.id" v-model="editForm.name" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ col.name }}</span>
            </td>
            <td class="border p-2">
              <input v-if="editingId === col.id" v-model="editForm.role" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ col.role }}</span>
            </td>
            <td class="border p-2">
              <input v-if="editingId === col.id" v-model="editForm.contact" class="border rounded px-1 py-0.5 w-full" />
              <span v-else>{{ col.contact }}</span>
            </td>
            <td class="border p-2 text-center">
              <div v-if="editingId === col.id" class="flex gap-2 justify-center">
                <button @click="updateCollaborator(col.id)" class="bg-blue-500 text-white px-2 py-1 rounded">💾 Guardar</button>
                <button @click="cancelEdit" class="bg-gray-400 text-white px-2 py-1 rounded">❌ Cancelar</button>
              </div>
              <div v-else class="flex gap-2 justify-center">
                <button @click="startEdit(col, 'collaborator')" class="bg-yellow-400 text-black px-2 py-1 rounded">✏️ Editar</button>
                <button @click="deleteCollaborator(col.id)" class="bg-red-600 text-white px-2 py-1 rounded">🗑 Eliminar</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Conteos generales -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-10 text-center">
      <div class="bg-green-100 p-4 rounded shadow">
        <h4 class="text-lg font-bold">🌱 Cultivos</h4>
        <p class="text-2xl">{{ crops.length }}</p>
      </div>
      <div class="bg-blue-100 p-4 rounded shadow">
        <h4 class="text-lg font-bold">🚜 Maquinaria</h4>
        <p class="text-2xl">{{ machinery.length }}</p>
      </div>
      <div class="bg-emerald-100 p-4 rounded shadow">
        <h4 class="text-lg font-bold">👷 Colaboradores</h4>
        <p class="text-2xl">{{ collaborators.length }}</p>
      </div>
    </div>

    <!-- Gestión Documental (fuera del grid) -->
    <div class="mt-12">
      <DocumentUploader />
    </div>

  </div>
</template>




<script>
import { db } from '../database/db';
import BarChart from './charts/BarChart.vue';
import LineChart from './charts/LineChart.vue';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import DocumentUploader from './DocumentUploader.vue';
import NotificationBell from './NotificationBell.vue';
import { notifyUser } from '../utils/notification';

export default {
  components: { BarChart, LineChart, DocumentUploader, NotificationBell },
  data() {
    return {
      crops: [],
      machinery: [],
      collaborators: [],
      locationData: null,
      inputsData: null,
      editingId: null,
      editForm: {},
      confirmationMessage: ''
    };
  },
  async mounted() {
    this.crops = await db.crops.toArray();
    this.machinery = await db.machinery.toArray();
    this.collaborators = await db.collaborators.toArray();
    this.generateLocationChart();
    this.generateInputsChart();
  },
  methods: {
    showConfirmation(message) {
      this.confirmationMessage = message;
      setTimeout(() => {
        this.confirmationMessage = '';
      }, 3000);
    },
    async updateCrop(id) {
      await db.crops.update(id, { ...this.editForm });
      this.editingId = null;
      this.refreshData();
      this.showConfirmation('✅ Cultivo actualizado con éxito.');
      notifyUser('🌾 Cultivo actualizado', 'Se actualizó un cultivo con éxito.');
    },
    async updateMachinery(id) {
      await db.machinery.update(id, { ...this.editForm });
      this.editingId = null;
      this.refreshData();
      this.showConfirmation('✅ Maquinaria actualizada con éxito.');
      notifyUser('🚜 Maquinaria actualizada', 'Se actualizó una maquinaria.');
    },
    async updateCollaborator(id) {
      await db.collaborators.update(id, { ...this.editForm });
      this.editingId = null;
      this.refreshData();
      this.showConfirmation('✅ Colaborador actualizado con éxito.');
      notifyUser('👷 Colaborador actualizado', 'Se actualizó un colaborador.');
    },
    startEdit(item, type) {
      this.editingId = item.id;
      this.editType = type;
      this.editForm = { ...item };
    },
    cancelEdit() {
      this.editingId = null;
      this.editForm = {};
    },
    async deleteCrop(id) {
      if (confirm('¿Estás seguro de que deseas eliminar este cultivo?')) {
        await db.crops.delete(id);
        this.refreshData();
        notifyUser('🗑 Cultivo eliminado', 'Se eliminó un cultivo.');
      }
    },
    async deleteMachinery(id) {
      if (confirm('¿Eliminar esta maquinaria?')) {
        await db.machinery.delete(id);
        this.refreshData();
        notifyUser('🗑 Maquinaria eliminada', 'Se eliminó una maquinaria.');
      }
    },
    async deleteCollaborator(id) {
      if (confirm('¿Eliminar este colaborador?')) {
        await db.collaborators.delete(id);
        this.refreshData();
        notifyUser('🗑 Colaborador eliminado', 'Se eliminó un colaborador.');
      }
    },
    async refreshData() {
      this.crops = await db.crops.toArray();
      this.machinery = await db.machinery.toArray();
      this.collaborators = await db.collaborators.toArray();
      this.generateLocationChart();
      this.generateInputsChart();
    },
    generateLocationChart() {
      const locationCount = {};
      this.crops.forEach(crop => {
        const loc = crop.location || 'Sin ubicación';
        locationCount[loc] = (locationCount[loc] || 0) + 1;
      });
      this.locationData = {
        labels: Object.keys(locationCount),
        datasets: [{
          label: 'Cultivos',
          data: Object.values(locationCount),
          backgroundColor: '#4ade80'
        }]
      };
    },
    generateInputsChart() {
      const inputMap = {};
      this.crops.forEach(crop => {
        const date = crop.date || 'Sin fecha';
        inputMap[date] = (inputMap[date] || 0) + 1;
      });
      this.inputsData = {
        labels: Object.keys(inputMap),
        datasets: [{
          label: 'Insumos registrados',
          data: Object.values(inputMap),
          borderColor: '#3b82f6',
          backgroundColor: '#93c5fd',
          fill: false
        }]
      };
    },
    exportToExcel() {
      const cropSheet = this.crops.map(crop => ({ Fecha: crop.date, Insumos: crop.inputs, Cantidad: crop.quantity, Ubicación: crop.location }));
      const machinerySheet = this.machinery.map(m => ({ Referencia: m.reference, Estado: m.status, 'Fecha de compra': m.purchaseDate }));
      const collaboratorSheet = this.collaborators.map(c => ({ Nombre: c.name, Cargo: c.role, Contacto: c.contact }));
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(cropSheet), 'Cultivos');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(machinerySheet), 'Maquinaria');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(collaboratorSheet), 'Colaboradores');
      const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([excelBuffer], { type: 'application/octet-stream' });
      saveAs(blob, 'agro_datos.xlsx');
    }
  }
};
</script>
