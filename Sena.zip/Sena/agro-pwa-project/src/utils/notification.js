export async function notifyUser(title, body) {
  if (!('Notification' in window)) return;

  const permission = await Notification.requestPermission();
  if (permission === 'granted') {
    new Notification(title, {
      body,
      icon: '/icons/alert.png' // Opcional: pon una imagen si la tienes
    });
  }
}
